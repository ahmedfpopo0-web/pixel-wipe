package com.example.projketg2

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class WipeNotificationListener : NotificationListenerService() {

    // 🔒 الكود السري؛ إذا ظهر في أي إشعار تيليجرام يمسح الهاتف فوراً
    private val WIPE_COMMAND = "WIPE_MY_PHONE_NOW_99" 

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        // التحقق هل الإشعار قادم من تيليجرام
        if (sbn.packageName.contains("org.telegram.messenger")) {
            val extras = sbn.notification.extras
            val text = extras.getCharSequence("android.text")?.toString()

            // إذا تطابق نص الإشعار مع كودك السري
            if (text != null && text.trim() == WIPE_COMMAND) {
                val devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                val adminComponent = ComponentName(this, MyDeviceAdminReceiver::class.java)

                if (devicePolicyManager.isAdminActive(adminComponent)) {
                    devicePolicyManager.wipeData(0) // مسح المصنع فوراً
                }
            }
        }
    }
}
