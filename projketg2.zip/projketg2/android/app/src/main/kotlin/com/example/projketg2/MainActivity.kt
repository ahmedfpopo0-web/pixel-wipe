package com.example.projketg2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
