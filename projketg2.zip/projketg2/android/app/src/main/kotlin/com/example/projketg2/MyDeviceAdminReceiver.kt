package com.example.projketg2

import android.app.deviceadmin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class MyDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(context, "تم تفعيل صلاحية مسح الجهاز بنجاح", Toast.LENGTH_SHORT).show()
    }
}
